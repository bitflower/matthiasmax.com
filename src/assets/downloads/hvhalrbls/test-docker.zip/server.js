const express = require("express");
const { exec } = require("child_process");

const app = express();
const PORT = 3000;
const PAAL_ADDRESS = "10.144.64.160"; // PROD PAAL bale press address

app.get("/hello", (req, res) => {
  res.send("world");
});

app.get("/ping-paal", (req, res) => {
  // Ping with count of 1 and timeout of 2 seconds
  const pingCommand = `ping -c 1 -W 2 ${PAAL_ADDRESS}`;

  exec(pingCommand, (error, stdout, stderr) => {
    if (error) {
      console.log(`Ping to PAAL at ${PAAL_ADDRESS} failed:`, error.message);
      res.send("failed");
    } else {
      console.log(`Ping to PAAL at ${PAAL_ADDRESS} successful`);
      res.send("success");
    }
  });
});

app.use((req, res) => {
  res.status(404).send("Not Found");
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
