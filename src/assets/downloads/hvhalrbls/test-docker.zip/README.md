# Hello World HTTP Service

A minimal Node.js HTTP service that runs in a Docker container and responds to GET requests.

## Overview

This microservice demonstrates a simple HTTP server implementation using Express.js, packaged as a Docker container. It's designed to test three critical capabilities on on-premise Linux VMs:

1. **Docker Build Capability** - Validates the VM can build Docker images
2. **NPM Registry Access** - Confirms internet connectivity to download packages during build
3. **PAAL Network Connectivity** - Tests network access to the production PAAL bale press (10.144.64.160)

## Features

- Express.js REST API server
- Docker containerized with multi-stage dependency installation
- Tests npm registry connectivity during build
- Alpine-based Docker image for minimal footprint
- Simple endpoint for validation testing

## Prerequisites

- [Docker](https://www.docker.com/get-started) installed on your system
- Port 3000 available on your host machine

## Project Structure

```
test-docker-microservice/
├── server.js          # Express.js HTTP server implementation
├── package.json       # npm dependencies (Express.js)
├── Dockerfile         # Docker image configuration with npm install
└── README.md          # This file
```

## Quick Start

### 1. Build the Docker Image

```bash
cd test-docker-microservice
docker build -t hello-http .
```

**What this validates:**
- Docker daemon is running and accessible
- Docker can pull base images (node:20-alpine)
- npm registry is accessible from the VM
- npm can download and install dependencies (Express.js + 75 packages)
- Build process completes without network or permission issues

### 2. Run the Container

**For PAAL connectivity testing (recommended on production VM):**
```bash
docker run --network host hello-http
```

**For local testing without PAAL access:**
```bash
docker run -p 3000:3000 hello-http
```

The server will start and listen on port 3000. You should see:
```
Server running on http://localhost:3000
```

**Note:** Host networking mode (`--network host`) is required to reach the PAAL bale press on the local network (10.144.64.160). Without it, the `/ping-paal` endpoint will return "failed".

### 3. Test the Service

In a new terminal, test the endpoints:

**Test basic endpoint:**
```bash
curl http://localhost:3000/hello
```

**Expected response:**
```
world
```

**Test PAAL connectivity:**
```bash
curl http://localhost:3000/ping-paal
```

**Expected response:**
- `success` - If PAAL at 10.144.64.160 is reachable
- `failed` - If PAAL is not reachable (no network access or wrong network mode)

## API Documentation

### GET /hello

Returns a plain text "world" response.

**Request:**
```bash
curl http://localhost:3000/hello
```

**Response:**
- **Status Code:** 200 OK
- **Content-Type:** text/plain
- **Body:** `world`

### GET /ping-paal

Tests network connectivity to the production PAAL bale press by sending a ping to 10.144.64.160.

**Request:**
```bash
curl http://localhost:3000/ping-paal
```

**Response:**
- **Status Code:** 200 OK
- **Content-Type:** text/plain
- **Body:**
  - `success` - PAAL is reachable on the network
  - `failed` - PAAL is not reachable

**Note:** Requires host networking mode (`docker run --network host`) to access the local network where the PAAL bale press resides.

### All Other Routes

Any other route will return a 404 error.

**Request:**
```bash
curl http://localhost:3000/any-other-path
```

**Response:**
- **Status Code:** 404 Not Found
- **Content-Type:** text/plain
- **Body:** `Not Found`

## Running Options

### Run in Foreground

**With host networking (for PAAL access):**
```bash
docker run --network host hello-http
```

**Without host networking (local testing only):**
```bash
docker run -p 3000:3000 hello-http
```

Press `Ctrl+C` to stop.

### Run in Background (Detached Mode)

**With host networking (for PAAL access):**
```bash
docker run -d --network host --name hello-http-service hello-http
```

**Without host networking (local testing only):**
```bash
docker run -d -p 3000:3000 --name hello-http-service hello-http
```

**Manage the container:**

```bash
# View logs
docker logs hello-http-service

# Stop the container
docker stop hello-http-service

# Start the container again
docker start hello-http-service

# Remove the container
docker rm hello-http-service
```

### Run on a Different Port

Map the container's port 3000 to a different host port:

```bash
docker run -p 8080:3000 hello-http
```

Then access at: `http://localhost:8080/hello`

## Development

### Running Without Docker

You can also run the service directly with Node.js:

```bash
# Install dependencies
npm install

# Start the server
npm start
# or
node server.js
```

**Requirements:**
- Node.js 20.x or higher
- Internet access to npm registry (for initial `npm install`)

### Modifying the Service

1. Edit `server.js`
2. Rebuild the Docker image
3. Stop and remove the old container
4. Run the new container

```bash
docker build -t hello-http .
docker stop hello-http-service
docker rm hello-http-service
docker run -d -p 3000:3000 --name hello-http-service hello-http
```

## Troubleshooting

### Port Already in Use

If you see an error about port 3000 being in use:

```bash
# Find what's using port 3000
lsof -i :3000

# Or run on a different port
docker run -p 3001:3000 hello-http
```

### Container Won't Start

Check Docker logs:

```bash
docker logs <container-id>
```

### Cannot Access Service

Verify the container is running:

```bash
docker ps
```

Check if the port mapping is correct and the service is listening.

### Build Fails During npm install

If the build fails when downloading packages:

1. **Check internet connectivity:**
   ```bash
   curl -I https://registry.npmjs.org
   ```

2. **Check if proxy settings are needed:**
   - Set npm proxy in Dockerfile if behind corporate firewall
   - Add `ENV HTTP_PROXY` and `ENV HTTPS_PROXY` before `RUN npm install`

3. **Verify npm registry is accessible:**
   ```bash
   docker run --rm node:20-alpine npm config get registry
   ```

## Acceptance Criteria

### Environment Validation
- ✅ Docker build completes successfully
- ✅ npm packages download from registry during build
- ✅ 75+ packages installed (Express.js and dependencies)

### Service Validation
- ✅ Container starts without errors
- ✅ Service listens on port 3000
- ✅ `GET /hello` returns HTTP 200 and body `world`
- ✅ `GET /ping-paal` returns HTTP 200 and body `success` or `failed`
- ✅ All other routes return HTTP 404

### Network Validation (on production VM)
- ✅ PAAL at 10.144.64.160 is reachable when using host networking mode
- ✅ `/ping-paal` endpoint returns `success` when PAAL is accessible

## Technical Details

**Base Image:** `node:20-alpine`
- Alpine Linux-based for minimal size (~40MB compressed)
- Node.js 20 LTS version

**Dependencies:**
- Express.js 4.18.2
- Total packages installed: ~75 (including transitive dependencies)
- Installed during Docker build via `npm install --production`

**Service Configuration:**
- Port: 3000
- Protocol: HTTP
- Framework: Express.js
- Response Format: Plain text

**Build Process:**
1. Pull node:20-alpine base image from Docker Hub
2. Copy package.json to container
3. Run `npm install` (requires npm registry access)
4. Copy application code
5. Set entry point to start server

## License

This is a test microservice for demonstration purposes.
